const mysql = require('mysql');
const express = require('express');

var app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.json());

var mysqlConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: "",
    database: 'dbemployee',
    multipleStatements: true,
    port: 3308
});

mysqlConnection.connect((err) => {
    if (!err){
        console.log('DB connection succeded.');
        console.log("DB connection succeded.")
    }
    else{
        console.log('DB connection failed \n Error : ' + JSON.stringify(err, undefined, 2));
    }
        
});


app.listen(8000, () => console.log('Express server is runnig at port no : 8000'));

//Insert employees
app.post('/employee', (req, res) => {
    console.log("called")
    console.log("body : "+req.body[0]);
    if(req.body.length>0){
        for(var i=0; i<req.body.length; i++){
            console.log(req.body.length)
            let emp = req.body[i];
            console.log(emp);
            if(emp!=null){
                var sql = "SET @EmployeeID = ?; SET @FirstName = ?; SET @LastName = ?; SET @Gender = ?; SET @Designation = ?; SET @Salary = ?; SET @City = ?; SET @Country = ?; \
                CALL employeeAdd(@EmployeeID, @FirstName, @LastName, @Gender, @Designation, @Salary, @City, @Country)";
                mysqlConnection.query(sql, [emp.EmployeeID, emp.FirstName, emp.LastName, emp.Gender, emp.Designation, emp.Salary, emp.City, emp.Country], (err, rows, fields) => {
                    try {
                        if (!err)
                            rows.forEach(element => {
                            if(element.constructor == Array)
                            res.send('Inserted employee id : '+element);
                        });
                    }catch{
                        console.log("err : "+err);
                    }
                })
            }else{
                res.send("data not available")
            }
        }
    }else{
        res.send("empty data");
    }
});

//get data
app.get('/employees', (req, res) => {
    mysqlConnection.query('select * from employeetable', (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    })
});