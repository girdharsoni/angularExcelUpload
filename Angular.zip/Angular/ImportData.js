var app = angular.module('app', []);  
  
app.controller('Ctrl', ['$scope', '$http', function ($scope, $http) {  
    
    console.log("run")
    $scope.selectedFile = null;  
    $scope.msg = "";  
  
    $scope.loadFile = function (files) {  
  
        $scope.$apply(function () {  
            console.log("load File")
            $scope.selectedFile = files[0];  
        })  
    }  
  
        $scope.handleFile = function () {  
        var file = $scope.selectedFile;  
        if (file) {  
            console.log(file);
            var reader = new FileReader();  
  
            reader.onload = function (e) {  
                console.log("onload")
                var data = e.target.result;  
                console.log({data})
                console.log("check")
                var workbook = XLSX.read(data, { type: 'binary' });  
                console.log("check1")
                console.log(workbook);
                var first_sheet_name = workbook.SheetNames[0];  
                console.log(first_sheet_name)
                var dataObjects = XLSX.utils.sheet_to_json(workbook.Sheets[first_sheet_name]);  
                console.log(dataObjects)
  
                if (dataObjects.length > 0) {  
                    console.log(dataObjects.length,dataObjects)
                    $scope.save(dataObjects);
                    //$scope.getData();
                   
                } else {  
                    $scope.msg = "Error : Something Wrong !";  
                }  
            }  
            reader.onerror = function (ex) {  
            }  
            reader.readAsBinaryString(file);  
        }  
    }  
  
    $scope.save = function (data) {  
        console.log("save DATA function");
        console.log(data);
        $http({    
            url: "http://localhost:8000/employee",  
            method: "POST",
            data: JSON.stringify(data),
            ContentType: 'application/json'  
            
        }).then(function successResponse(data) {  
            if (data.status) {  
                console.log(data.status);
                $scope.msg = "Data has been inserted ! ";  
            }  
            else {  
                $scope.msg = "Error : Something Wrong yes";  
            }  
        }, function errorResponse(error) {  
            console.log(error)
            $scope.msg = "Error : Something Wrong no";  
        })  
    }
    
    $scope.getData = function () {  
        console.log("get DATA function");
        $http({    
            url: "http://localhost:8000/employees",  
            method: "GET",
            ContentType: 'application/json'  
            
        }).then(function successResponse(data) {  
            if (data.status) {  
                console.log(data);
                $scope.msg = "Data has been inserted ! ";  
            }  
            else {  
                $scope.msg = "Error : Something Wrong yes";  
            }  
        }, function errorResponse(error) {  
            console.log(error)
            $scope.msg = "Error : Something Wrong no";  
        })  
    }  
}]);

// //getData optional way
// $http.get('http://127.0.0.1:8000/employees').
// then(function(response) {
//     console.log( response.data);
// });

// //postData optional way
// var url="http://127.0.0.1:8000/employee";
// $http.post(`${url}`,JSON.stringify(dataObjects)).
// then(function(response) {
//     console.log(response.data); 
// });